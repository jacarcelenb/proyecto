<?php
session_start();

$conn = mysqli_connect(
  "162.241.62.202",
  "asamble8_admin001",
  "-d{Mi?BbQccl",
  "asamble8_fundacion_proyecto"
) or die(mysqli_erro($mysqli));

?>