<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../css/correo.css">
  </head>
  <body>
    <div class="center">
      <h1>Correo enviado correctamente</h1>
        <div class="signup_link">
           <a href="contacto.php">Regresar</a>
        </div>
     
    </div>

  </body>
</html>