<?php  


?>

<div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">  
					<center><img src="../images/proyectos.png" alt="" class="img-responsive"/>
					<a href="listarproyectos.php" class="btn btn-success">Proyectos</a>
				
				</center>
						
					</div>
					<div class="col-md-4">  
					<center><img src="../images/quejas.png" alt="" class="img-responsive">
					<a href="listarquejas.php"  class="btn btn-success">Quejas</a>
				    </center>
						
					</div>
					<div class="col-md-4">  
					<center><img src="../images/inscripcion.png" alt="" class="img-responsive">
					<a href="listarinscripciones.php" class="btn btn-success">Inscripciones</a>
				</center>
						
					</div>				
				</div>
			</div>
		</div>