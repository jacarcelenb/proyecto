<aside class="mg-widget">
								<h2 class="mg-widget-title">Areas de Trabajo</h2>
								<ul class="mg-recnt-posts">
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="salud.php">Salud y Bienestar</a></h3>
											<p>ASAMBLEA IMBABURA RENACIENTE,  es una organización que tiene como...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="educacion.php">Educación </a></h3>
											<p>Restaurar El Estado Plurinacional De Ecuador...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="comunicacion.php">Comunicaciones</a></h3>
											<p>Los gobiernos han tratado de reprimir la voz de la gente ...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="finanza.php">Finanzas</a></h3>
											<p>El sistema finaciero global ha sido monopolizado...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="ambiente.php">Ambiente</a></h3>
											<p>Hoy en día estamos aconteciendo ...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="gia.php">GIA</a></h3>
											<p>La Agencia de Inteligencia Global fue...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="alimentos.php">Life force Ecuador</a></h3>
											<p>El objetivo de ASAMBLEA IMBABURA RENACIENTE, </p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="asambleas.php">Asamblea life force Ecuador</a></h3>
											<p>La Asamblea cumple la función de Organizar...</p>
										</div>
									</li>
								</ul>
							</aside>