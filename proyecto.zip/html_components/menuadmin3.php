<?php  


?>

<div class="mg-blog-list">
			<div class="container">
				<div class="row">
				
					<div class="col-md-4">  
						<center><img src="../images/ICONO-NOTICIAS.jpg" alt="" class="img-responsive">
						<a href="listarnoticias.php" class="btn btn-success">Noticias</a>
					</center>
						
					</div>
					<div class="col-md-4">  
					<center><img src="../images/video1.png" alt="" class="img-responsive">
					<a href="listarvideos.php" class="btn btn-success">Videos</a>
				</center>
					</div>
					<div class="col-md-4">  
					<center><img src="../images/fotos.png" alt="" class="img-responsive">
					<a href="listarfotos.php" class="btn btn-success">Fotos</a>
				</center>
					</div>
					<div class="col-md-4">  
					<center><img src="../images/actividades.png" alt="" class="img-responsive">
					<a href="listaractividades.php"class="btn btn-success">Actividades</a>
					<center>
					</div>
					<div class="col-md-4">  
					<center><img src="../images/blog.png" alt="" class="img-responsive">
					<a href="listarblogs.php"class="btn btn-success">Blogs</a>
					<center>
					
					</div>
					

										
										
				</div>
			</div>
		</div>