<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>SALUD</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
							<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta4.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Salud y Bienestar</h2>
								</header>
								<div>
									<p>
									El comité de Salud y Bienestar, tiene a su cargo la restauración integral del Ser Humano, considerándolo como un ente integral, con salud física, mental, emocional y espiritual. Por tanto, su bienestar psico-biológico repercute en el éxito social y económico de toda la comunidad.  Para dicho fin, utilizaremos todos los medios de salud holística, de conexión interna, con la naturaleza y el equilibrio integral.
									</p>

									
						
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>


<BR><BR>        
<?php include('../html_components/footer.php'); ?>