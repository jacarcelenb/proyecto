
<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>RESTAURACIÓN</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta13.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Restauración</h2>
								</header>
								<div>
									

								<p>
								Es responsable de evaluar las necesidades de las personas y las comunidades en las que viven, Se espera que este comité desarrolle programas, directrices y asociaciones comunitarias para identificar con precisión los problemas actuales o futuros y evaluar lo que se necesita para resolverlos mejor.
								</p> <br>
								<p>
								Este comité trabaja junto con los comités correspondientes dentro de la Asamblea para planificar, diseñar, implementar, administrar y financiar los proyectos requeridos.
								</p><br>
								<p>
								En consecuencia, este comité supervisa el progreso y actúa como una plataforma de retroalimentación para la comunidad que estimulo la necesidad y el proyecto que se creó para satisfacer esa necesidad.
								</p>
					
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>