<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>Misión Visión</h2>
						<p>Misión / Visión</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<main>

							<article class="mg-post">
								<header>
									<a href="#"><img src="images/mision.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">MISION/VISION</h2>
									
								</header>
								<div>
									<p><strong>MISION</strong> 
									ASAMBLEA IMBABURA RENACIENTE, tiene como misión ejecutar todas las actividades que contribuyan al logro de los objetivos; participar en la construcción y en el desarrollo de programas y proyectos en el ámbito de nuestra competencia, velar porque dichos objetivos estén concorde a la visión y se pongan en práctica para el libre ejercicio de los derechos de los seres vivos.
</p>
						
						<p></p>
						
						<p><strong>VISION</strong> 
						Buscamos el bien común de los seres humanos de manera global, desarrollando iniciativas y proyectos que busquen el desarrollo integral de los ciudadanos buscando la inclusión de las personas más vulnerables en procesos económicos y sociales que mejoren no sólo su calidad de vida, sino sobre todo la valoración de la dignidad como seres humanos, encaminados a conseguir el desarrollo humano y la integridad social, en especial de los sectores más vulnerables y excluidos de los procesos económicos y sociales, respetando el medio ambiente y a todo ser vivo.
</p>
						
						
								</div>
								
							</article>
						</main>
						
						
						
					</div>
					<div class="col-md-4">
						<div class="mg-widget-area">
							
							<aside class="mg-widget">
								<h2 class="mg-widget-title">Nosotros</h2>
								<ul class="mg-recnt-posts">
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="historia.php">Nosotros</a></h3>
											<p>ASAMBLEA IMBABURA RENACIENTE,  es una organización que tiene como...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="misionvision.php">Misión </a></h3>
											<p>Restaurar El Estado Plurinacional De Ecuador...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="misionvision.php">Visión</a></h3>
											<p>Integrar Al Proyecto ASAMBLEA IMBABURA RENACIENTE, , A Toda La Comunidad...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="directiva.php">Asamblea</a></h3>
											<p>Las Asambleas Departamentales y Comunales...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="acercade.php">Acerca de</a></h3>
											<p>ASAMBLEA IMBABURA RENACIENTE,  Global...</p>
										</div>
									</li>
								</ul>
							</aside>
							
							
						</div>
					</div>
				</div>
			</div>
		</div><BR><BR>        
<!--    FIN CONTENIDO     -->
<?php include('../html_components/footer.php'); ?>