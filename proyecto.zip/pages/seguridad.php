
<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>SEGURIDAD</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta9.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Seguridad</h2>
								</header>
								<div>
									

								<p>
								Este comité actuara cuando exista una emergencia, crisis o desastre de carácter antropogénico o natural que generó un impacto o que podría generar pérdidas y daños en territorio provincial, también se incluye en caso de que una amenaza haya afectado a otros territorios y se desee apoyar en la respuesta, reconstrucción o recuperación en diferentes ámbitos.

								</p><br>
								<p>
                                Apoyará en la recuperación de la resiliencia, construyendo comunidades resilientes a través de la capacitación y preparación en prevención y mitigación, así como también definir protocolos, metodologías y procesos para la respuesta, reconstrucción, rehabilitación, logrando así reducir los riesgos de desastres, velará por la confraternidad entre sus semejantes.

								</p>
					
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>