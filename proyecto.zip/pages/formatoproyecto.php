<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>Formato de proyectos</h2>
						<p></p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     -->		<div class="mg-page">
			<div class="container">
				<div class="row">
					
					<div class="col-md-12">
						<iframe src="../recursos/Formulario de presentación de proyectos.pdf" marginwidth="0" marginheight="0" name="ventana_iframe" scrolling="no" border="0" 
frameborder="0" width="900" height="900">
						</iframe> 
					</div>
                    
                    
					
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>