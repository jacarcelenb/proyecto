
<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>COMUNICACIONES</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta10.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Comunicaciones</h2>
								</header>
								<div>
									<p>
									Los gobiernos han tratado de reprimir la voz de la gente bloqueando a quienes están dispuestos a decir la verdad, para abordar esta injusticia y restaurar la voz de la gente se ha creado el comité de comunicación que más que redes sociales, son medios profesionales para llenar de justicia y verdad al mundo.
El comité de Comunicación es el órgano encargado que genera y ejecuta directrices comunicacionales tanto interna y externa, bajo los principios de libertad democratización y equilibrio de la información sobre los acontecimientos de los proyectos y su impacto con total transparencia y realidad social territorial, con total respeto a la diversidad de actores y culturas que conforman como sociedad con derechos parte del estado intercultural y plurinacional del Ecuador.

									</p>
						
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>


<BR><BR>        
<?php include('../html_components/footer.php'); ?>