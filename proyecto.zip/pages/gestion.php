
<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>GESTIÓN DE PROYECTOS</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta12.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Gestión de proyectos</h2>
								</header>
								<div>
									

								<p>
								Este comité de gestión de proyectos es el encargado de la planificación, ejecución y seguimiento de un proyecto desde el inicio hasta el fin con la finalidad de alcanzar los objetivos propuestos por las comunidades.
								</p>
					
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>