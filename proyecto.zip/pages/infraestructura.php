
<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>INFRAESTRUCTURA Y OBRAS PÚBLICAS</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta11.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Infraestructura y Obras públicas</h2>
								</header>
								<div>
									

								<p>
								Los responsables de formular, implementar y evaluar políticas, regulaciones, planes, programas y proyectos que garantizan una red de transporte seguro y competitivo, minimizando el impacto ambiental y contribuyendo al desarrollo social y económico de los pueblos has desviado los presupuestos dejando al desamparo sectores vulnerables. 
 Por ello este comité se crea para velar porque los recursos económicos provenientes de LIFE FORCE GLOBAL sean canalizados adecuadamente hacia la construcción de un verdadero bienestar social de la comunidad imbabureña, construyendo obras de infraestructura con tecnología de punta, en un ambiente libre de corrupción, con planteamientos bien marcados de auto sustentabilidad y seguridad comunitaria, aplicando altas normativas del bien vivir con altos valores humanos, pero sobre todo respetando las bases intrínsecas de la madre naturaleza.   

								</p>
					
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>