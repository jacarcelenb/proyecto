<?php 
include("../dbcontroller/database.php");
session_destroy();
header("Location: ../pages/sesion1.php")
?>