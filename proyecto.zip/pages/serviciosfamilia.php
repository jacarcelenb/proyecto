
<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>SERVICIOS PARA LA FAMILIA</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta8.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Servicios para la familia</h2>
								</header>
								<div>
									

								<p>
								La familia es una sociedad natural, que existe antes que el Estado o cualquier otra comunidad, y que posee derechos propios e inalienables. Por este motivo, constituye la célula básica de la sociedad y se conforma en elemento angular del desarrollo social. La familia, como síntesis de los impulsos humanos más profundos (sociabilidad, afectividad, etc.), no es creación de ninguna época humana, sino patrimonio de todas las edades y civilizaciones. La familia es mucho más que una unidad jurídica, social y económica ya que hablar de familia es hablar de vida, de transmisión de valores, de educación, de solidaridad, de estabilidad, de futuro, en definitiva, de amor.
								</p><br>
								<p>
								Dando la esencial importancia a la familia y a sabiendas que la crisis familiar empieza por las carencias que puede vivir la misma, el comité de A-LIFE IMBABURA RENACIENTE encargado de la familia tiene un imperativo trabajo desarrollando programas que puedan solventar todas sus necesidades íntegramente para salvaguardar el núcleo de la sociedad. 
								</p>
					
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>