
<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>EDUCACIÓN</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta6.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Educación</h2>
								</header>
								<div>
									

								<p>Ante los actuales desafíos principalmente los resultados de la pandemia en la calidad de la educación en nuestros niños y jóvenes, nos basamos en poner énfasis en la calidad de vida, valorar más el presente, educar para el ahora, educar para el cambio y generar un educando distinto cuyas características principales serían educar para pensar y no para obedecer órdenes, con total flexibilidad, inclinación hacia la democracia, la justicia y la seguridad.
							</p>
					
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>
<BR><BR>        
<?php include('../html_components/footer.php'); ?>