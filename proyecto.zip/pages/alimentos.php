<?php include('../html_components/header.php'); ?>


		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>LIFE FORCE ECUADOR</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta2.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Life Force Ecuador</h2>
								</header>
								<div>
									<p>Une personas de honor, con discernimiento, responsabilidad integridad para propiciar el desarrollo armónico de la sociedad. </p>
									<br>
									<p>
									Supervisa el normal funcionamiento de los proyectos individuales y sociales, para que estos se lleven a cabo de acuerdo a lo planificado, especialmente velaran por el cuidado del planeta, preocupándose de la producción de alimentos saludable, la no contaminación, la utilización de energías renovables entre muchas otras cosas.
									</p>
									<br>
									<p>
									La asamblea Nacional estará compuesta con el mínimo de miembros que sean capaces de administrar las diferentes áreas que tenga el respectivo país, así, por ejemplo:
Agrícola, Salud, Obras Públicas, Social, Seguridad, Justicia, Informática, Finanzas, Comunicaciones, Energía, Hídrica, Medio Ambiente, Etc. 

									</p>
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>

	<BR><BR>        
	<?php include('../html_components/footer.php'); ?>