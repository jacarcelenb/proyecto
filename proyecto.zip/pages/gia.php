<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>GIA</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta1.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">GIA</h2>
								</header>
								<div>
									<p><strong>La Agencia de Inteligencia Global </strong>
									fue controlada anteriormente por diferentes entidades y desde entonces ha sido depurada y reestructurada para operar como la Agencia de Aplicación del Repositorio Global. El GIA es responsable de garantizar que todas las transacciones que salen del Repositorio Global se utilicen para el Plan de Restauración.
								</p>
						
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>

<BR><BR>        
<!--    FIN CONTENIDO     -->
<?php include('../html_components/footer.php'); ?>