
		<?php include('../html_components/header.php'); ?>
		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>Acerca de</h2>
						<p></p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<main>

							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/logoGlobalpeque.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">LIFE FORCE GLOBAL</h2>
									
								</header>
								<div>
									<p><strong>LIFE FORCE</strong> 
<strong>LIFE FORCE</strong> es una organización que tiene como misión <strong>LA RESTAURACION DE NUESTRO PLANETA, DEVOLVIENDO A LOS SERES HUMANOS EL DERECHO A UNA VIDA DIGNA Y PLENA</strong>, erradicando el hambre, la esclavitud en todas sus formas, el abuso de poder, y cualquier forma de daño o degradación. <strong>FOMENTANDO LA UNIDAD PARA </strong> vivir en armonía y ASI erradicar las diferencias sociales, o cualquier otro comportamiento que haya sido creado para dividir y enfrentar a los seres humanos.<br><br>
<strong>TODO GRAN CAMBIO COLECTIVO INICIA CON UN CAMBIO INDIVIDUAL, CULTIVANDO  LA CONECCION CON EL ESPIRITU DIVINO QUE SOMOS Y DE ESA MANERA LOGRAR LA ELEVACION DE LA CONCIENCIA Y DE NUESTRA ENERGIA.</strong><br><br>
<strong>EN EL ORDEN DE LA MATERIA</strong>, se distribuirán las riquezas que durante muchos siglos estuvieron administradas y acaparadas por un grupo REDUCIDO de personas, las CUALES IMPIDIERON LA DISTRIBUCION igualitaria de esa riqueza, manteniéndonos en condiciones que en muchos lugares era infrahumana.
</p>
					
						
						
								</div>
								
							</article>
						</main>
						
						
						
					</div>
					<div class="col-md-4">
						<div class="mg-widget-area">
							
							<aside class="mg-widget">
								<h2 class="mg-widget-title">Nosotros</h2>
								<ul class="mg-recnt-posts">
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="historia.php">Nosotros</a></h3>
											<p>LIFE FORCE es una organización que tiene como...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="misionvision.php">Misión </a></h3>
											<p>Restaurar El Estado Plurinacional De Bolivia...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="misionvision.php">Visión</a></h3>
											<p>Integrar Al Proyecto Life Force, A Toda La Comunidad...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="directiva.php">Asamblea</a></h3>
											<p>Las Asambleas Departamentales y Comunales...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="acercade.php">Acerca de</a></h3>
											<p>Life force Global...</p>
										</div>
									</li>
								</ul>
							</aside>
							
							
						</div>
					</div>
				</div>
			</div>
		</div><BR><BR>        
		<?php include('../html_components/footer.php'); ?>