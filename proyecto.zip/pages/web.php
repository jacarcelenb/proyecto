<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>PLATAFORMA WEB</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
							<aside class="mg-widget">
								<h2 class="mg-widget-title">Areas de Trabajo</h2>
								<ul class="mg-recnt-posts">
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="salud.php">Cuidado de la Salud</a></h3>
											<p>ASAMBLEA IMBABURA RENACIENTE,  es una organización que tiene como...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="educacion.php">Educación </a></h3>
											<p>Restaurar El Estado Plurinacional De Ecuador...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="comunicacion.php">Medios de Comunicación</a></h3>
											<p>Atención médica diseñada para enseñar a las...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="finanza.php">Sistema Financiero</a></h3>
											<p>El sistema finaciero global ha sido monopolizado...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="web.php">Plataforma Web</a></h3>
											<p>G-FORCE NETWORK es una plataforma de redes...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="gia.php">GIA</a></h3>
											<p>La Agencia de Inteligencia Global fue...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="alimentos.php">Alimentos</a></h3>
											<p>El objetivo de ASAMBLEA IMBABURA RENACIENTE, </p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date"><i class="fa fa-cogs"></i></div>
											<h3><a href="asambleas.php">Asambleas</a></h3>
											<p>La Asamblea cumple la función de Organizar...</p>
										</div>
									</li>
								</ul>
							</aside>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/web.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Plataforma Web</h2>
								</header>
								<div>
									<p><strong>G-FORCE	NETWORK	es	una	plataforma	de	redes	sociales</strong> profesional para personas con un mismo propósito que desean
				   conectarse con otras personas que están inspiradas para cambiar el mundo </p>
						
				<p>No toleraremos a los trolls pagados para causar división, retórica de odio o grupos formados en torno a intenciones negativas,  pornografía o blasfemias excesivas.</p>
						
				<p>Esta comunidad está formada por emprendedores que participan en debates inteligentes, proponen soluciones viables y aceptan la diversidad de ser nuestro yo único y sorprendente. Creemos que nuestras	diferencias,	así	como	nuestras similitudes,	nos empoderan como individuos y como fuerza comunitaria de la naturaleza capaz de lograr cualquier cosa.
				</p>
				
				<p>Fomentamos la formación de páginas comerciales para Empresas Éticas en cualquier etapa de desarrollo, Grupos Comunitarios, Asambleas, Equipos de Desarrollo de Proyectos y Think Tanks para colaborar, empoderar y expandir las posibilidades, oportunidades,  comprensión e impacto de todos en el G- RED DE FUERZA.  </p>
				
				<p>Somos la nueva plataforma para los miembros de ASAMBLEA IMBABURA RENACIENTE,  Global, un movimiento dedicado a la restauración del planeta, las personas y la energía vital que nos conecta a todos. Estamos emocionados de tenerte aquí y dedicarnos a tu éxito.
				</p>
						
				<p>Estamos con la gente y G-FORCE es un llamado a la acción para el gigante dentro de ti. Vamos a cambiar el mundo. Juntos.
					</p>
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>



		<BR><BR>        
<?php include('../html_components/footer.php'); ?>