<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>A-LIFE IMBABURA RENACIENTE</h2>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta3.png" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">A-LIFE IMBABURA RENACIENTE</h2>
								</header>
								<div>
									<p>Analizamos las necesidades de nuestra comunidad, sus causas y creamos oportunidades de desarrollo aplicado de ciencia y tecnología utilizando soluciones sanas, saludables y compatibles con la vida en planes de transformación auténtica para superar las condiciones de pobreza, hambre y enfermedades. </p>						
					</div>
				</div>
			</div>
		</div>


<BR><BR>        
<?php include('../html_components/footer.php'); ?>