
<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>Nuestra Directiva</h2>
						<p>Directiva</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-8">
						<main>

							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/asambleas.PNG" width="700" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Asamblea Life Imbabura Renaciente</h2>
									
								</header> 
								<div align="justify">
									<p>
									Las Asambleas Provinciales, están compuesta por miembros de Life Force, que viven en sus respectivas provincias. A su vez cada asamblea provincial esta compuesta de una directiva y sus comités, conformándose así: Presidente, Secretario, Tesorería , Sargento de armas , Investigador Judicial, Seguridad, Ambiente, Educación e investigación, Salud y bienestar , Servicios de familia, Comunicación, Gestión de proyectos, Obras públicas e infraestructura y Restauración.
Esta asamblea se reporta con la Asamblea Nacional, los miembros que componemos dependeremos de los rubros que requiera la provincia para llevar una eficiente labor en cada área.

									</p>
									
									
								</div>
								<p>
									<a href="mailto:secretaria.lifeir@gmail.com " style="color:darkgreen">secretaria.lifeir@gmail.com </a>
								</p>
								<!-----<a href="#"><img src="images/mesaDirectiva2.jpg" alt="" class="img-responsive"></a>-------->
								
								
							
							</article>
						</main>
					
						

					
						
					</div>
					<div class="col-md-4">
						<div class="mg-widget-area">
							
							<aside class="mg-widget">
								<h2 class="mg-widget-title">Nosotros</h2>
								<ul class="mg-recnt-posts">
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="historia.php">Nosotros</a></h3>
											<p>ASAMBLEA IMBABURA RENACIENTE,  es una organización que tiene como...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="misionvision.php">Misión </a></h3>
											<p>Restaurar El Estado Plurinacional De Ecuador...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="misionvision.php">Visión</a></h3>
											<p>Integrar Al Proyecto ASAMBLEA IMBABURA RENACIENTE, , A Toda La Comunidad...</p>
										</div>
									</li>
									<li>
										<div class="mg-recnt-post">
											<div class="mg-rp-date">&#9679; </div>
											<h3><a href="directiva.php">Asamblea</a></h3>
											<p>Las Asambleas Departamentales y Comunales...</p>
										</div>
									</li>
								</ul>
							</aside>
							
							
						</div>
					</div>
				</div>
			</div>
		</div><BR><BR>        
<!--    FIN CONTENIDO     -->
<?php include('../html_components/footer.php'); ?>
	