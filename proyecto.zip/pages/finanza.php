<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>FINANZAS</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-blog-list">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="mg-widget-area">
						<?php include("../html_components/workarea.php");?>
						</div>
					</div>
					
					
					<div class="col-md-8">
						<main>
							<article class="mg-post">
								<header>
									<a href="#"><img src="../images/resta5.jpg" alt="" class="img-responsive"></a>
									<h2 class="mg-post-title">Finanzas</h2>
								</header>
								<div>
									<p> El sistema financiero ha sido seriamente monopolizado por un mínimo porcentaje de individuos a nivel mundial, las entidades que pertenecen a este monopolio reciben dinero de los depositantes y lo prestan a quienes lo solicitan a altos intereses, muchas veces estas personas en el intento de adquirir un bien terminan endeudadas por toda su vida o simplemente pierde su capital o inversión en el intento de querer pagar. Este ciclo funciona de forma continua y simultánea. </p>
						
						
								</div>
							</article>
						</main>
					</div>
				</div>
			</div>
		</div>


		<BR><BR>     
		
	<?php include('../html_components/footer.php'); ?>
