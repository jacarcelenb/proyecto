<?php include('../html_components/header.php'); ?>

		<div class="mg-page-title parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>PROYECTOS</h2>
						<p> .</p>
					</div>
				</div>
			</div>
		</div>
<!--    INICIO CONTENIDO     --><div class="mg-page">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mg-booking-form">

							<div class="tab-content">
								<div role="tabpanel" class="tab-pane fade in active" id="select-room">
									
									<div class="mg-available-rooms">
										<h2 class="mg-sec-left-title">Estado Plurinacional de Ecuador</h2>
										<div class="mg-avl-rooms">
											<div class="mg-avl-room">
												<div class="row">
													<div class="col-sm-3">
														<a href="https://repositorio.cepal.org/bitstream/handle/11362/36629/1/S2014195_es.pdf"><img src="images/pdf.png" alt="" class="img-responsive"></a>
													</div>
													<div class="col-sm-7">
														<h3 class="mg-avl-room-title"><a href="#">Estado Plurinacional de Ecuador</a></h3>
														<p>Estado Plurinacional de Ecuador: acerca de las transformaciones del Estado y la gestión del desarrollo ...</p>
														
														<a href="https://repositorio.cepal.org/bitstream/handle/11362/36629/1/S2014195_es.pdf" class="btn btn-main">Bajar información</a>
														
													</div>
												</div>
											</div>
											<div class="mg-avl-room">
												<div class="row">
													<div class="col-sm-3">
														<a href="http://biblioteca.clacso.edu.ar/clacso/coediciones/20130214112018/ElnacimientodelEstadoPlurinacional.pdf"><img src="images/pdf.png" alt="" class="img-responsive"></a>
													</div>
													<div class="col-sm-7">
														<h3 class="mg-avl-room-title"><a href="#">Estado Plurinacional de Ecuador</a></h3>
														<p>Estado Plurinacional de Ecuador: acerca de las transformaciones del Estado y la gestión del desarrollo ...</p>
														
														<a href="http://biblioteca.clacso.edu.ar/clacso/coediciones/20130214112018/ElnacimientodelEstadoPlurinacional.pdf" class="btn btn-main">Bajar información</a>
														
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
								
								
							</div>

						</div>
					</div>
				</div>
			</div>
		</div><BR><BR>        
		<?php include('../html_components/footer.php'); ?>